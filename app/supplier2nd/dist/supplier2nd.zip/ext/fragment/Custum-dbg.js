sap.ui.define([], function() {
    'use strict';

    return {
        predefinedMethod: function() {}
    };
});
